package teaching.last;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * @author HeRunLin
 */
public class IntegerArgumentMarshaler implements ArgumentMarshaler {

    private int integerValue = 0;

    @Override
    public void set(Iterator<String> currentArgument) throws ArgsException {
        String parameter = null;
        try {
            parameter = currentArgument.next();
            integerValue = Integer.parseInt(parameter);
        } catch (NoSuchElementException e) {
//				errorCode= ErrorCode.MISSING_INTEGER;
            throw new ArgsException(ArgsException.ErrorCode.MISSING_INTEGER);
        } catch (NumberFormatException e) {
//				errorParameter = parameter;
//				errorCode= ErrorCode.INVALID_INTEGER;
            throw new ArgsException(ArgsException.ErrorCode.INVALID_INTEGER, parameter);
        }
    }

    @Override
    public Object get() {
        return integerValue;
    }
}