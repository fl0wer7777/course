package main.step8_last;

/**
 * @author HeRunLin
 * @version 1.0
 * @className ChildrenPrice
 * @date 2021-10-24 20:47:53
 */
public class ChildrenPrice extends Price{
    @Override
    public int getPriceCode() {
        return Movie.CHILDREN;
    }

    @Override
    public double getCharge(int daysRented) {
        double result = 1.5;
        if (daysRented > 3) {
            result += (daysRented - 3) * 1.5;
        }
        return result;
    }
}
