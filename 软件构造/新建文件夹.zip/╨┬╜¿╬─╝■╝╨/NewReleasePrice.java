package main.step8_last;

/**
 * @author HeRunLin
 * @version 1.0
 * @className NewReleasePrice
 * @date 2021-10-24 20:48:05
 */
public class NewReleasePrice extends Price {

    @Override
    public int getPriceCode() {
        return Movie.NEW_RELEASE;
    }

    @Override
    public double getCharge(int daysRented) {
        return daysRented * 3;
    }

    @Override
    public int getFrequentRenterPoints(int daysRented) {
        return (daysRented > 1) ? 2 : 1;
    }
}
