package main.step8_last;

/**
 * @author HeRunLin
 * @version 1.0
 * @className Price
 * @date 2021-10-24 20:46:54
 */
public abstract class Price {

    abstract int getPriceCode();
    abstract double getCharge(int daysRented);
    public int getFrequentRenterPoints(int daysRented) {
        return 1;
    }
}

