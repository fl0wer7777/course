package main.step8_last;

/**
 * @author HeRunLin
 * @version 1.0
 * @className RegularPrice
 * @date 2021-10-24 20:48:21
 */
public class RegularPrice extends Price{

    @Override
    public int getPriceCode() {
        return Movie.REGULAR;
    }

    @Override
    public double getCharge(int daysRented) {
        double result = 2;
        if (daysRented > 2) {
            result += (daysRented - 2) * 1.5;
        }
        return result;
    }
}
